/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package schedulingalgorithms;


import AlgorithmCode.*;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author yara
 */
public class SchedulingAlgorithms {
    
   
        

    /**
     * @param args the command line arguments
     */
    @SuppressWarnings("empty-statement")
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
       
//      

      int pnum; 
      int[]at; 
      int[]bt; 
      int[]pr;
      int[]pc;
      int q; 
      
      
      
      
      


        System.out.println("*******************************************");
        System.out.println("* Welcome to the Simple Scheduler Program *");
        System.out.println("*******************************************");
        System.out.println();
        int temp=0; 
       while(temp==0)  
       {
           
           System.out.println("What would you like to do?");
           System.out.println("    1. Enter Process Details ");
           System.out.println("    2. Load Process Details From Text File");
        
        
        Scanner sc= new Scanner(System.in);
        int x= sc.nextInt();
        char c;
        System.out.println();
 
        if(x==1)
        {
           System.out.println("Please Enter Process Details... ");
           System.out.println();
           System.out.print("Number of processes: ");
           pnum=sc.nextInt();
           at= new int[pnum];
           bt=new int[pnum];
           pr=new int[pnum];
       
           System.out.print("Arrival Time: ");
           for(int i=0;i<pnum;i++)
               at[i]= sc.nextInt();
           System.out.print("Burst Time: "); 
           for(int j=0; j<pnum;j++)
               bt[j]=sc.nextInt();
           System.out.println();
           
           System.out.println("Pick An Algorithm to Implement:");
           System.out.println("    1. First-Come-First-Served (FCFS)");
           System.out.println("    2. Shortest-Job-First (SJF)");
           System.out.println("    3. Priority Scheduling");
           System.out.println("    4. Round Robin (RR)");
           x=sc.nextInt();
         
            switch(x)
            {
                case 1:
                    System.out.println();
                    System.out.println("Note: FCFS is Only a Non-Preemptive Algorithm.");
                    System.out.println();
                    FCFSCode f= new FCFSCode();
                    f.setPnum(pnum);
                    f.setAT(at);
                    f.setBT(bt);
                    f.fcfs();
                    break;
                case 2:
                    SJFCode s= new SJFCode();
                    s.setPnum(pnum);
                    s.setAT(at);
                    s.setBT(bt);
                    System.out.println("For Preemptive Enter 1, For Non-Preemptive Enter 2");
                   
                    x= sc.nextInt();
                   
                    if(x==1)
                    {
                        System.out.println();
                        System.out.println("Note: The Preemptive Version of the SJF Algorithm is Called Shortest-Remaining-Time-First(SRTF)");
                        System.out.println();
                        s.srtf();
                    }
                    
                    else 
                      s.npsjf();
                    break;
                    
                case 3: 
                    PriorityCode p= new PriorityCode();
                    p.setPnum(pnum);
                    p.setAT(at);
                    p.setBT(bt);
                    System.out.print("Please enter the priority for each process in order. (highest priority: 1) ");
                    for(int k=0; k<pnum;k++)
                        pr[k]=sc.nextInt();
                    p.setPR(pr);
                    System.out.println();
                    System.out.println("Note: Priority Scheduling can be both preemptive and non-preemptive. This application only calculates non-preemptive.");
                    System.out.println();
                      p.npPriority();
                  
                    break;
                
                case 4: 
                    RRCode r= new RRCode();
                    r.setPnum(pnum);
                    r.setAT(at);
                    r.setBT(bt);
                    System.out.println("Please enter the time quantum: ");
                    q=sc.nextInt();
                    r.setQ(q);
                    System.out.println();
                    System.out.println("Note: Round Robin is only a preemptive algorithm.");
                    System.out.println();
                    r.rr();
                    break;
                    
                default:   
                    System.out.println("Please enter a valid choice.");
                    break;

            }
            
                    
         
        }
        
        //loading from file
    
        
        else
        {
             
         
            System.out.println("Do You Want To Load a File:");
         
            System.out.println("     1.With Arrival Time");
            System.out.println("     2.Wtithout Arrival Time");
            sc.nextInt();
            int i=0;
            String data;
           
            pc= new int[4];
            at= new int[4];
            bt= new int[4];
          
            switch(x)
             {
                
                case 1: 
                {    
                    File f1= new File("src/vpat.txt");
                    Scanner scf= new Scanner(f1);
                    while(scf.hasNext())
                    {
                        data = scf.nextLine();
                        Scanner dsc= new Scanner(data);
                        dsc.useDelimiter(",");
                        pc[i]=Integer.parseInt(dsc.next());
                        bt[i]=Integer.parseInt(dsc.next());
                        at[i]=Integer.parseInt(dsc.next());
                       
                        i++;       
                        
                    }
                    break;
                 }
                    
                case 2: 
                {
                    File f2= new File("src/pat0.txt");
                
                    Scanner fsc = new Scanner(f2);
                 
                    
                    while(fsc.hasNext())
                    {
                        data = fsc.nextLine();
                        Scanner dsc= new Scanner(data);
                        dsc.useDelimiter(", ");
                        pc[i]=Integer.parseInt(dsc.next());
                        bt[i]=Integer.parseInt(dsc.next());
                        at[i]=Integer.parseInt(dsc.next()); 
                    
                        i++;
                      
                    }
                     
                    break;
                }    
                        
                 
                default:    
                    System.out.println("Please enter a valid choice.");
                    break;
            
            
             }
           System.out.println("Pick An Algorithm to Implement:");
           System.out.println("    1. First-Come-First-Served (FCFS)");
           System.out.println("    2. Shortest-Job-First (SJF)");
           System.out.println("    3. Priority Scheduling");
           System.out.println("    4. Round Robin (RR)");
           x=sc.nextInt();
         
            switch(x)
            {
                case 1:
                    System.out.println();
                    System.out.println("Note: FCFS is Only a Non-Preemptive Algorithm.");
                    System.out.println();
                    FCFSCode f= new FCFSCode();
                    f.setPnum(4);
                    f.setAT(at);
                    f.setBT(bt);
                    f.fcfs();
                    break;
                case 2:
                    SJFCode s= new SJFCode();
                    s.setPnum(4);
                    s.setAT(at);
                    s.setBT(bt);
                    System.out.println("For Preemptive Enter 1, For Non-Preemptive Enter 2");
                    x= sc.nextInt();
                    if(x==1)
                    {
                        System.out.println();
                        System.out.println("Note: The Preemptive Version of the SJF Algorithm is Called Shortest-Remaining-Time-First (SRTF)");
                        System.out.println();
                        s.srtf();
                    }
                    else s.npsjf();
                    break;
                    
                case 3: 
                    PriorityCode p= new PriorityCode();
                    p.setPnum(4);
                    p.setAT(at);
                    p.setBT(bt);
                    pr= new int[4];
                    System.out.print("Please enter the priority for each process in order. (highest priority: 1) ");
                    for(int k=0; k<4;k++)
                        pr[k]=sc.nextInt();
                    System.out.println("Note: Priority Scheduling can be both preemptive and non-preemptive. This program only calculates non-preemptive.");
                    System.out.println();
                     p.npPriority();
                    break;
                
                case 4: 
                    RRCode r= new RRCode();
                    r.setPnum(4);
                    r.setAT(at);
                    r.setBT(bt);
                    System.out.println("Please enter the time quantum: ");
                    q=sc.nextInt();
                    r.setQ(q);
                    System.out.println();
                    System.out.println("Note: Round Robin is only a preemptive algorithm.");
                    System.out.println();
                    r.rr();
                    break;
                    
                default:   
                    System.out.println("Please enter a valid choice.");
                    break;

            }
       
       
        }
        
            System.out.println();
            System.out.println("------------------------------------------------");
            System.out.println();
            System.out.println("Would You Like To Try Another Algorithm? (Y/N)");
            c= sc.next().charAt(0);
            switch(c)
            {
                case 'Y':
                    continue;
                case 'N':
                    temp++;
                    break;
            
            }
       
       }
       }
    }



        
       
        
       
       
     
        
        
        
        
        
  

    
    
