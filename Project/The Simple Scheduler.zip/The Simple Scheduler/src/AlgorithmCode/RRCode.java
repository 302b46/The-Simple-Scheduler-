/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AlgorithmCode;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;

/**
 *
 * @author yara
 */
public class RRCode {
    
    
  
    private int[] pc; 
    private int[]bt; 
    private int[]at; 
    private int q; //quantum
    private int pnum;

    
    
    public int[] getPC() {return pc;}
    public int[] getAT(){return at;}
    public int[] getBT(){return bt;}
    public int getQ(){return q;}
    public int getPnum(){return pnum;}
    
   
    public void setAT(int[] at){this.at=at;}
    public void setBT(int[] bt){this.bt=bt;}
    public void setQ(int q){this.q=q;}
    public void setPnum(int pnum)
    {
        this.pnum=pnum;
        pc= new int[pnum];
    }
  
  
  public void rr() throws IOException
  {
      
      int n=pnum;
      int[]ct = new int[n];//completion time
      int[]wt = new int[n];
      int[]tat = new int[n];
      int cs=0; //context switching
      int[]btc= bt.clone(); //burst time copy
      int[]atc=at.clone(); //arrival time copy
      int currt=0; //current time
      int temp;
      
      
      
      //sorting at
      for(int i = 0 ; i <n; i++)
            {
                for(int  j=0;  j < n-(i+1) ; j++)
                {
                    if( at[j] > at[j+1] )
                    {
                        temp = at[j];
                        at[j] = at[j+1];
                        at[j+1] = temp;
                        temp = bt[j];
                        bt[j] = bt[j+1];
                        bt[j+1] = temp;
                        temp = pc[j];
                        pc[j] = pc[j+1];
                        pc[j+1] = temp;
                    }
                }
            }
      
        while (true) { 
            boolean complete = true; 
            for (int i = 0; i < n; i++) { 
  
                
                if (atc[i] <= currt) { 
                    
                    cs++;
                    if (atc[i] <= q) { 
                        if (btc[i] > 0) { 
                            complete = false; 
                            if (btc[i] > q) { 
  
                                currt+=q; 
                                btc[i]-= q; 
                                atc[i]+=q; 
                           
                          
                            } 
                            else { 
  
                                currt+=btc[i]; 
                                ct[i] = currt - at[i];
                                wt[i] = currt - bt[i] - at[i]; 
                                btc[i] = 0; 
                             
  
                            } 
                        } 
                    } 
                    else if (atc[i] > q) { 
                        
                        cs++;
  
                
                        for (int j = 0; j < n; j++) { 
  
                            // compare 
                            if (atc[j] < atc[i]) { 
                                if (btc[j] > 0) { 
                                    complete = false; 
                                    if (btc[j] > q) { 
                                        currt+=q; 
                                        btc[i]-= q; 
                                        atc[i]+=q;
                                    } 
                                    else { 
                                        currt+=btc[i]; 
                                        ct[i] = currt - at[i];
                                        wt[i] = currt - bt[i] - at[i]; 
                                        btc[i] = 0;  
                                    } 
                                } 
                            } 
                            
                        } 
  
                       
                        if (btc[i] > 0) { 
                            complete = false; 
  
                            if (btc[i] > q) { 
                                 currt+=q; 
                                 btc[i]-= q; 
                                 atc[i]+=q;
                            } 
                            else { 
                                currt+=btc[i]; 
                                ct[i] = currt - at[i];
                                wt[i] = currt - bt[i] - at[i]; 
                                btc[i] = 0;  
                            } 
                        } 
                    } 
                } 
  
             
                else if (atc[i] > currt) { 
                    currt++; 
                    i--; 
                }
                
                
                
            } 
         
            if (complete) { 
                break; 
            } 
            
            
        }

       


        
        for(int f=0; f<n;f++)
             tat[f]= bt[f] + wt[f];
        float wtsum=0, tatsum=0, ctsum=0, avgwt, avgtat, avgct; 
 
         for(int j=0; j<n;j++)
         {
             wtsum+=wt[j];
             tatsum+=tat[j];
             ctsum+=ct[j];
             
         }
     
             avgwt=wtsum/n;
             avgtat=tatsum/n;
             avgct=ctsum/n;
             
          System.out.println("Process "+"     "+"Arrival Time"+"       "+"Burst Time"+"      "+"Waiting Time "+ "      "+"Turn Around Time"+"      "+"Completion time");

         for(int k=0; k<n;k++)
            System.out.println("P"+(k+1)+"                 "+at[k]+"                 "+bt[k]+"              "+wt[k]+"   \t\t"+tat[k]+"\t\t\t"+ct[k]);
         System.out.println();
         System.out.println("Average waiting time: "+avgwt);
         System.out.println("Average turn around time: "+avgtat);
         System.out.println("Average response time: "+avgct);
         System.out.println("Context switching: "+cs);
         

    
         
         
         
          //writing results into file
       
       String titles="Process     Arrival Time     Burst Time     Waiting Time     Turn Around Time     Completion Time\n";

        try (BufferedWriter bw = new BufferedWriter(new FileWriter("results.txt",true))) {
            bw.write("\n");
            bw.write("        \t\t   ROUND ROBIN RESULTS\n");
            bw.write("\n");
            bw.write(titles);
            for(int w=0; w<n;w++)
                bw.write("P"+(w+1)+ " \t\t" + at[w]+" \t\t"+bt[w]+" \t\t"+wt[w]+"      \t\t"+tat[w]+"\t\t  \t"+ct[w]+"\n");
            
            bw.write("\n");
            bw.write("Average Waiting Time: "+ avgwt);
            bw.write("\n");
            bw.write("Average Turn Around Time: "+avgtat);
            bw.write("\n");
            bw.write("Average Response Time: "+avgct);
            bw.write("\n");
            bw.write("Context Switching: "+cs);
            bw.write("\n");
            bw.write("------------------------------------------------------------------------------------------------------------------------");
            bw.close();
        }
  
        
        } 
  
    } 
      
     
     
     
      
  
   
  
  
  

   

