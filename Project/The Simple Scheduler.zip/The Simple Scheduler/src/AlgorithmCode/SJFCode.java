/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AlgorithmCode;


import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;


/**
 *
 * @author yara
 */
public class SJFCode {
    

   private int[] pc; 
   private int[]bt; 
   private int[]at; 
   private int pnum;
 

    
    
    public int[] getPC() {return pc;}
    public int[] getAT(){return at;}
    public int[] getBT(){return bt;}
    public int getPnum(){return pnum;}
    
   
    public void setAT(int[] at){this.at=at;}
    public void setBT(int[] bt){this.bt=bt;}
   public void setPnum(int pnum)
    {
        this.pnum=pnum;
        pc= new int[pnum];
    }
 
public void sort()
  { 
      
       for(int i=0; i<pnum;i++)
       {
           for(int j=0;j<pnum-i-1; j++) //j=i+1, j<n?
           {
               if(at[j]>at[j+1]) //sorting arrival time
               {
                   Arrays.sort(at);
                   Arrays.sort(bt);
                   Arrays.sort(pc);
               }
               
               if(at[j]==at[j+1]) //sorting burst time
               {
                   if(bt[j]>bt[j+1])
                   {
                      Arrays.sort(at);
                      Arrays.sort(bt);
                      Arrays.sort(pc);
                   }
               
               }
               
           }
          
       }
  
  }
  
 
  //NON-PREEMPTIVE
 

 
  public void npsjf() throws IOException
  {
      int n=pnum;
      int[]wt=new int[n];
      int[]tat=new int[n];
      int[]ct= new int[n]; //completion time
      int[]finished=new int[n];
      int cs=n-1; //context switching

     
     sort();
      
     int st=0, total=0; //st: start time
     
        while(true)
        {
            int c=n, min = Integer.MAX_VALUE;

            if (total == n)
                break;

            for (int i=0; i<n; i++)
            {

                if ((at[i] <= st) && (finished[i] == 0) && (bt[i]<min))
                {
                    min=bt[i];
                    c=i;
                }
            }
            if (c==n)
                st++;
            else
            {
                ct[c]=st+bt[c];
                st+=bt[c];
                tat[c]=ct[c]-at[c];
                wt[c]=tat[c]-bt[c];
                finished[c]=1;
                pc[total] = c + 1;
                total++;
            }
        }
  
 
         float wtsum=0, tatsum=0, ctsum=0, avgwt, avgtat, avgct; 
 
         for(int j=0; j<n;j++)
         {
             wtsum+=wt[j];
             tatsum+=tat[j];
             ctsum+=ct[j];
         }
     
     avgwt=wtsum/n;
     avgtat=tatsum/n;
     avgct=ctsum/n;
     
     
      System.out.println("Process "+"     "+"Arrival Time"+"       "+"Burst Time"+"      "+"Waiting Time "+ "      "+"Turn Around Time"+"      "+"Completion time");

         for(int k=0; k<n;k++)
            System.out.println("P"+(k+1)+"                 "+at[k]+"                 "+bt[k]+"              "+wt[k]+"   \t\t"+tat[k]+"\t\t\t"+ct[k]);
     System.out.println();
     System.out.println("Average waiting time: "+avgwt);
     System.out.println("Average turn around time: "+avgtat);
     System.out.println("Average response time: "+avgct);
     System.out.println("Context switching: "+cs);
     
     
            
             //writing results into file
       
       String titles="Process     Arrival Time     Burst Time     Waiting Time     Turn Around Time     Completion Time\n";

        try (BufferedWriter bw = new BufferedWriter(new FileWriter("results.txt", true))) {
            bw.write("\n");
            bw.write("        \t\t   NON-PREEMPTIVE SJF RESULTS \n");
            bw.write("\n");
            bw.write(titles);
            for(int w=0; w<n;w++)
                bw.write("P"+(w+1)+ " \t\t" + at[w]+" \t\t"+bt[w]+" \t\t"+wt[w]+"      \t\t"+tat[w]+"\t\t  \t"+ct[w]+"\n");
            bw.write("\n");
            bw.write("Average Waiting Time: "+ avgwt);
            bw.write("\n");
            bw.write("Average Turn Around Time: "+avgtat);
            bw.write("\n");
            bw.write("Average Response Time: "+avgct);
            bw.write("\n");
            bw.write("Context Switching: "+cs);
            bw.write("\n");
            bw.write("------------------------------------------------------------------------------------------------------------------------");
            
            bw.close();
        }
     
     }


  
//---------------------------------------------------------------------------//
  
  
//  PREEMPTIVE / Shortest-Remaining-Time-First(SRTF)
  
  public void srtf() throws IOException
  {
      int n=pnum;
      int[]wt=new int[n];
      int[]tat=new int[n];
      int[]ct= new int[n];
      int[]rembt= bt.clone(); //remaining burst time
      int ft; //finish time
      int cs=0, cp=0, t=0,shortest=0, min=Integer.MAX_VALUE; //cs: context switching, cp: completed processes, t: time
      boolean check =false; 
      
      while(cp!=n)
      {
          for(int j=0; j<n;j++)
          {
              if((at[j]<=t) && (rembt[j] < min) && (rembt[j]>0))
              {
                  min=rembt[j];
                  shortest=j; 
                  check=true;
                  
              }
          }
          
          
          if(check==false)
              t++;
          
          rembt[shortest]--;
          
          min=rembt[shortest];
          
          if(min==0)
              min=Integer.MAX_VALUE;
          
          //if process is completely executed
          if(rembt[shortest]==0)
          {
              cp++;
              check=false;
              ft=t+1; //finish time of current process
              wt[shortest]= ft - bt[shortest] - at[shortest];
              cs++;
              if(wt[shortest]<0)
                  wt[shortest]=0;
          
          }
          
          t++;
     
    
      }
      
      for(int j=0; j<n;j++)
      {
          tat[j]= bt[j] + wt[j];
          ct[j]= tat[j] + at[j];
      }
         float wtsum=0, tatsum=0,ctsum=0, avgwt, avgtat,avgct; 
         for(int j=0; j<n;j++)
         {
             wtsum+=wt[j];
             tatsum+=tat[j];
             ctsum+=ct[j];
         }

     avgwt=wtsum/n;
     avgtat=tatsum/n;
     avgct=ctsum/n;
     
 System.out.println("Process "+"     "+"Arrival Time"+"       "+"Burst Time"+"      "+"Waiting Time "+ "      "+"Turn Around Time"+"      "+"Completion time");

         for(int k=0; k<n;k++)
            System.out.println("P"+(k+1)+"                 "+at[k]+"                 "+bt[k]+"              "+wt[k]+"   \t\t"+tat[k]+"\t\t\t"+ct[k]);
     System.out.println();
     System.out.println("Average waiting time: "+avgwt);
     System.out.println("Average turn around time: "+avgtat);
     System.out.println("Average response time: "+avgct);
     System.out.println("Context switching: "+cs);
     
     System.out.println();
     
      //writing results into file
       
       String titles="Process     Arrival Time     Burst Time     Waiting Time     Turn Around Time     Completion Time\n";

        try (BufferedWriter bw = new BufferedWriter(new FileWriter("results.txt",true))) {
            bw.write("\n");
            bw.write("        \t\t   PREEMPTIVE SJF RESULTS (SRTF)\n");
            bw.write("\n");
            bw.write(titles);
            for(int w=0; w<n;w++)
                bw.write("P"+(w+1)+ " \t\t" + at[w]+" \t\t"+bt[w]+" \t\t"+wt[w]+"      \t\t"+tat[w]+"\t\t  \t"+ct[w]+"\n");
            bw.write("\n");
            bw.write("Average Waiting Time: "+ avgwt);
            bw.write("\n");
            bw.write("Average Turn Around Time: "+avgtat);
            bw.write("\n");
            bw.write("Average Response Time: "+avgct);
            bw.write("\n");
            bw.write("Context Switching: "+cs);
            bw.write("\n");
            bw.write("------------------------------------------------------------------------------------------------------------------------");
            
            bw.close();
        }
      
      
  }

}
  

  

  
  

