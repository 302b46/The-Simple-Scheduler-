/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AlgorithmCode;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;

/**
 *
 * @author yara
 */



public class FCFSCode {
   
    
//NON-PREEMPTIVE 

    private int[] pc; 
    private int[]bt; 
    private int[]at; 
    private int pnum; 
  

    
    
    public int[] getPC() {return pc;}
    public int[] getAT(){return at;}
    public int[] getBT(){return bt;}
    public int getPnum(){return pnum;}
   
    public void setAT(int[] at){this.at=at;}
    public void setBT(int[] bt){this.bt=bt;}
    public void setPnum(int pnum)
    {
        this.pnum=pnum;
        pc= new int[pnum];
    }
    
    
 

  public void sort()
  {  
       for(int i=0; i<pnum;i++)
       {
           for(int j=0;j<pnum-i-1; j++)
           {
               if(at[j]>at[j+1])
               {
                   Arrays.sort(at);
                   Arrays.sort(bt);
                   Arrays.sort(pc);
               }
               
           }
          
       }
  
  }
    public void fcfs() throws IOException
    {
        int n=pnum;
        int[]st= new int[n]; //service time
        int[]wt=new int[n];
        int[]tat=new int[n];
        int[]ct= new int[n]; //completion time
        int cs=n-1; //context switching
        
        sort();
    
        st[0]=0; 
        wt[0]= 0;
        tat[0]=bt[0]+wt[0];
        for(int i=1; i<n;i++)
        {
           
             st[i]=st[i-1] + bt[i-1];
             wt[i]= st[i] - at[i];
             tat[i]=bt[i] + wt[i];
             ct[i]=tat[i] + at[i];
             
         
             if(wt[i]<0)
                 wt[i]=0;
          
        
        }
   
        float wtsum=0, tatsum=0,ctsum=0, avgwt, avgtat,avgct; 
         for(int j=0; j<n;j++)
         {
             wtsum+=wt[j];
             tatsum+=tat[j];
             ctsum+=ct[j];
         }

     avgwt=wtsum/n;
     avgtat=tatsum/n;
     avgct=ctsum/n;
     
    System.out.println("Process "+"     "+"Arrival Time"+"       "+"Burst Time"+"      "+"Waiting Time "+ "      "+"Turn Around Time"+"      "+"Completion time");

         for(int k=0; k<n;k++)
            System.out.println("P"+(k+1)+"                 "+at[k]+"                 "+bt[k]+"              "+wt[k]+"   \t\t"+tat[k]+"\t\t\t"+ct[k]);
     System.out.println();
     System.out.println("Average waiting time: "+avgwt);
     System.out.println("Average turn around time: "+avgtat);
     System.out.println("Average response time: "+avgct);
     System.out.println("Context switching: "+cs);
     
     System.out.println();
     System.out.println("\n\t\t GANTT CHART \n\t\t");
            
            
            int i;
            for(i=1;i<=n;i++)
            {
                System.out.print("\t| P["+i+"] ");
            }
            
            System.out.println("|");
            for(i=0;i<n;i++)
            {
                if (i==0)
                {
                     System.out.print("\t"+wt[i]);
                     System.out.print("\t"+ct[i]);
                }
               else
                {
                    System.out.print("\t"+ct[i]);
                }
            }
            System.out.println("\n");
    
            
       //writing results into file
       
       String titles="Process     Arrival Time     Burst Time     Waiting Time     Turn Around Time     Completion Time\n";

        try (BufferedWriter bw = new BufferedWriter(new FileWriter("results.txt", true))) {
             bw.write("\n");
             bw.write("        \t\t   FCFS RESULTS \n");
             bw.write("\n");
             bw.write(titles);
           
            for(int w=0; w<n;w++)
                bw.write("P"+(w+1)+ " \t\t" + at[w]+" \t\t"+bt[w]+" \t\t"+wt[w]+"      \t\t"+tat[w]+"\t\t  \t"+ct[w]+"\n");
            
            bw.write("Average Waiting Time: "+ avgwt);
            bw.write("\n");
            bw.write("Average Turn Around Time: "+avgtat);
            bw.write("\n");
            bw.write("Average Response Time: "+avgct);
            bw.write("\n");
            bw.write("Context Switching: "+cs);
            bw.write("\n");
            bw.write("------------------------------------------------------------------------------------------------------------------------");
            bw.close();
            
        }
       
       
       
    }
    
   
    

    
    



 
    
    
    
    
    
    
    
}


